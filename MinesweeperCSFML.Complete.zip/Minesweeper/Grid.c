#include <SFML/Graphics.h>

#include "Grid.h"

Cell* CellCreate(sfVector2f size, sfVector2f pos, sfColor color) 
{
	sfRectangleShape* newShape = sfRectangleShape_create();
	sfRectangleShape_setSize(newShape, size);
	sfRectangleShape_setPosition(newShape, pos);
	sfRectangleShape_setFillColor(newShape, color);

	sfText* newText = sfText_create();
	sfFont* newFont = sfFont_createFromFile("Resources/Roboto-Regular.ttf");
	if (!newFont)
	{
		return NULL;
	}
	sfText_setString(newText, "_");
	sfText_setFont(newText, newFont);
	sfText_setCharacterSize(newText, CELL_SIZE);
	sfText_setColor(newText, sfColor_fromRGBA(255, 255, 255, 0));
	sfText_setPosition(newText, pos);

	Cell* newCell = (Cell*)malloc(sizeof(Cell));
	newCell->shape = newShape;
	newCell->bDiscovered = false;
	newCell->bFlagged = false;
	newCell->bPlanted = false;
	newCell->explosiveNeighbor = 0;
	newCell->text = newText;
	return newCell;
}

void CellDraw(Cell* cell, sfRenderWindow* window)
{
	if (cell->text != NULL) 
	{
		if (DEBUG_DRAW_CELL) printf("Try to draw cell text..");
		sfRenderWindow_drawText(window, cell->text, NULL);
		if (DEBUG_DRAW_CELL) printf("Text has been draw !");
	}

	if (cell->shape != NULL) 
	{
		if(DEBUG_DRAW_CELL) printf("Try to draw cell shape..");
		sfRenderWindow_drawRectangleShape(window, cell->shape, NULL);
		if (DEBUG_DRAW_CELL) printf("Shape has been draw !");
	}
}

int CellReveal(Grid* grid, sfVector2i cellGridPos)
{
	Cell* cell = grid->cells[cellGridPos.x][cellGridPos.y];

	// Debug message to trace the cell being revealed
	if (DEBUG_REVEAL_CELL) printf("Try to reveal cell x:%d y:%d ..\n", cellGridPos.x, cellGridPos.y);

	// If the cell is already discovered or flagged, do nothing and return false
	if (cell->bDiscovered || cell->bFlagged)
	{
		return 0;
	}

	// If the cell is planted with a bomb, return true to indicate game over
	if (cell->bPlanted)
	{
		return FAILURE;
	}
	
	// Change the cell's appearance to revealed (lighter color)
	sfRectangleShape_setFillColor(cell->shape, sfColor_fromRGBA(255, 255, 255, 100));
	cell->bDiscovered = true;

	// If the cell has explosive neighbors, display the number
	if (cell->explosiveNeighbor > 0) {

		// Safe conversion of the neighbor count (int) to a string
		char buffer[2];
		snprintf(buffer, sizeof(buffer), "%d", cell->explosiveNeighbor);
		sfText_setString(cell->text, buffer);

		sfText_setColor(cell->text, sfColor_fromRGBA(255, 255, 255, 255));
	}

	// If the cell is completely empty (explosiveNeighbor == 0), start the "flood fill"
	if (cell->explosiveNeighbor == 0)
	{
		int currentX = cellGridPos.x;
		int currentY = cellGridPos.y;

		// Loop through all 8 neighbors (3x3 area, excluding the center)
		for (int dx = -1; dx <= 1; dx++)
		{
			for (int dy = -1; dy <= 1; dy++)
			{
				// Skip the current cell itself
				if (dx == 0 && dy == 0)
					continue;

				int newX = currentX + dx;
				int newY = currentY + dy;

				// Check bounds to ensure the neighbor is within the grid
				if (newX >= 0 && newX < GRID_SIZE && newY >= 0 && newY < GRID_SIZE)
				{
					sfVector2i neighborPos = { newX, newY };

					// Recursive call to reveal the neighbor.
					// The recursion stops automatically when it hits a discovered cell or a numbered cell.
					CellReveal(grid, neighborPos);
				}
			}
		}
	}

	grid->discoveredCellCount++;
	// If all none planted cells are discovered, terminate the game
	if (grid->discoveredCellCount >= ((GRID_SIZE * GRID_SIZE) - BOMB_COUNT))
	{
		return SUCCESS;
	}

	// Return 0 as the cell was revealed and was not a bomb
	return 0;
}

void CellFlag(Grid* grid, sfVector2i cellGridPos)
{
	Cell* cell = grid->cells[cellGridPos.x][cellGridPos.y];

	// If the cell is already discovered, do nothing and return
	if (cell->bDiscovered)
	{
		return;
	}

	if (cell->bFlagged)
	{
		cell->bFlagged = false;
		sfText_setString(cell->text, "_");
		sfText_setColor(cell->text, sfColor_fromRGBA(255, 255, 255, 0));
		sfRectangleShape_setFillColor(cell->shape, sfColor_fromRGBA(255, 255, 255, 255));
	} else
	{
		cell->bFlagged = true;
		sfText_setString(cell->text, "F");
		sfText_setColor(cell->text, sfColor_fromRGBA(0, 0, 255, 255));
		sfRectangleShape_setFillColor(cell->shape, sfColor_fromRGBA(255, 255, 255, 100));
	}
}

void CellDestroy(Cell* cell)
{
	sfRectangleShape_destroy(cell->shape);
	sfText_destroy(cell->text);
}

Grid* GridCreate()
{
	// Create all cell and register them in grid array
	Grid* newGrid = (Grid*)malloc(sizeof(Grid));
	newGrid->discoveredCellCount = 0;

	for (int i = 0; i < GRID_SIZE; i++)
	{
		for (int j = 0; j < GRID_SIZE; j++)
		{
			sfVector2f size = { CELL_SIZE, CELL_SIZE };
			sfVector2f pos = { GRID_OFFSET + (i * (CELL_SIZE + CELL_OFFSET)), GRID_OFFSET + (j * (CELL_SIZE + CELL_OFFSET)) };
			newGrid->cells[i][j] = CellCreate(size, pos, sfColor_fromRGB( 255, 255, 255));
		}
	}

	return newGrid;
}

void GridPlantBomb(Grid* grid, int bombCount, sfVector2i cellToAvoid)
{
	// Plant all bomb and avoid avoided spot
	for (int i = 0; i < bombCount; i++)
	{
		bool bombPlanted = false;
		while (!bombPlanted) 
		{
			sfVector2i pos = { rand() % GRID_SIZE, rand() % GRID_SIZE };
			if (pos.x != cellToAvoid.x || pos.y != cellToAvoid.y) 
			{
				if (!grid->cells[pos.x][pos.y]->bPlanted) 
				{
					grid->cells[pos.x][pos.y]->bPlanted = true;
					if(DEBUG_BOMB) sfRectangleShape_setFillColor(grid->cells[pos.x][pos.y]->shape, sfColor_fromRGB(255, 0, 0));
					
					bombPlanted = true;
					if (DEBUG_PLANT_BOMB) printf("Plant bomb at x: %d y: %d \n", pos.x, pos.y);

					// Add 1 to explosiveNeighbor of every cell around this bombed cell
					for (int j = 0; j < 3; j++)
					{
						int posx = pos.x - 1 + j;
						if (posx >= 0 && posx <= GRID_SIZE - 1)
						{
							for (int k = 0; k < 3; k++)
							{
								int posy = pos.y - 1 + k;
								if (posy >= 0 && posy <= GRID_SIZE - 1)
								{
									if (posx != pos.x || posy != pos.y)
									{
										grid->cells[posx][posy]->explosiveNeighbor += 1;
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

sfVector2i GridUpdateLoop(Grid* grid, sfRenderWindow* window) 
{
	sfVector2i mousePos = sfMouse_getPositionRenderWindow(window);

	sfVector2i cellCoord = { -1,-1 };

	for (int i = 0; i < GRID_SIZE; i++)
	{
		for (int j = 0; j < GRID_SIZE; j++)
		{
			// If cell is already discovered or has been flagged, don't show hovered animation
			if (grid->cells[i][j]->bDiscovered || grid->cells[i][j]->bFlagged) continue;

			sfFloatRect cell = sfRectangleShape_getGlobalBounds(grid->cells[i][j]->shape);
			if (sfFloatRect_contains(&cell, mousePos.x, mousePos.y))
			{
				cellCoord.x = i;
				cellCoord.y = j;
				if (DEBUG_CURRENT_CELL_HOVERED) printf("Cell x:%d y:%d is hovered!\n", i, j);
				sfRectangleShape_setFillColor(grid->cells[i][j]->shape, sfColor_fromRGB(100, 100, 100));
			}
			else {
				sfRectangleShape_setFillColor(grid->cells[i][j]->shape, sfColor_fromRGB(255, 255, 255));
			}
		}
	}

	return cellCoord;
}

void GridDraw(Grid* grid, sfRenderWindow* window)
{
	if (DEBUG_DRAW_GRID) printf("Start drawing Grid... \n");
	for (int i = 0; i < GRID_SIZE; i++)
	{
		if (DEBUG_DRAW_GRID) printf("Try to draw at : x-> %d \n", i);
		for (int j = 0; j < GRID_SIZE; j++)
		{
			if (DEBUG_DRAW_GRID) printf("Try to draw at : y-> %d \n", j);
			if (grid->cells[i][j])
				CellDraw(grid->cells[i][j], window);
		}
	}
}

void GridDestroy(Grid* grid)
{
	for (int i = 0; i < GRID_SIZE; i++)
	{
		for (int j = 0; j < GRID_SIZE; j++)
		{
			CellDestroy(grid->cells[i][j]);
		}
	}
}
